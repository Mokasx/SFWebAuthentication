# 1.1.5 (03/23/2020)
* Merged [PR from petergrau](https://github.com/jwelker110/cordova-plugin-ios-aswebauthenticationsession-api/pull/2) renaming
variable to prevent collision with cordova-plugin-sfauthenticationsession when both are used in project.

# 1.1.4 (02/22/2020)
* Merged [PR from pizzapanther](https://github.com/jwelker110/cordova-plugin-ios-aswebauthenticationsession-api/pull/1/) referencing cordova namespace
when calling exec.

# 1.1.3 (11/27/2019)
* Wait for application to become active before calling start()

# 1.1.1 (10/23/2019)
* Remove editor files from packaging.

# 1.1.0 (10/23/2019)
* Conform to ASWebAuthenticationPresentationContextProviding protocol in iOS 13.